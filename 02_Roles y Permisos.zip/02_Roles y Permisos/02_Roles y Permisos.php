<?php

/************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
************************************************************************************************************/
1. En el archivo   ===>   config\web.php 

---------------------------------------------------components------------------------------------------------
	'components'=>[
		'user' => [
			'class' => 'webvimark\modules\UserManagement\components\UserConfig',

			// Comment this if you don't want to record user logins
			'on afterLogin' => function($event) {
					\webvimark\modules\UserManagement\models\UserVisitLog::newVisitor($event->identity->id);
				}
		],

	],

----------------------------------------------------modules--------------------------------------------------
	'modules'=>[
		'user-management' => [
			'class' => 'webvimark\modules\UserManagement\UserManagementModule',

			// 'enableRegistration' => true,

			// Add regexp validation to passwords. Default pattern does not restrict user and can enter any set of characters.
			// The example below allows user to enter :
			// any set of characters
			// (?=\S{8,}): of at least length 8
			// (?=\S*[a-z]): containing at least one lowercase letter
			// (?=\S*[A-Z]): and at least one uppercase letter
			// (?=\S*[\d]): and at least one number
			// $: anchored to the end of the string

			//'passwordRegexp' => '^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$',
			
			// Here you can set your handler to change layout for any controller or action
			// Tip: you can use this event in any module
			'on beforeAction'=>function(yii\base\ActionEvent $event) {
					if ( $event->action->uniqueId == 'user-management/auth/login' )
					{
						$event->action->controller->layout = 'loginLayout.php';
					};
				},
		],
	],

/************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
************************************************************************************************************/

4. En el archivo   ===>   vendor\webvimark\components\BaseController.php

	public function behaviors()
	{
		return [
			'ghost-access'=> [
				'class' => 'webvimark\modules\UserManagement\components\GhostAccessControl',
			],
		];
	}


/************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
************************************************************************************************************/
5.0 Respaldar el archivo   ===> views\layouts\main.php  ,  como  ===> views\layouts\main_original.php 
5.1 Escribir en el archivo ===> views\layouts\main.php  lo siguiente...?>

<?php
use webvimark\modules\UserManagement\components\GhostMenu;
use webvimark\modules\UserManagement\UserManagementModule;

echo GhostMenu::widget([
	'encodeLabels'=>false,
	'activateParents'=>true,
	'items' => [
		[
			'label' => 'Backend routes',
			'items'=>UserManagementModule::menuItems()
		],
		[
			'label' => 'Frontend routes',
			'items'=>[
				['label'=>'Login', 'url'=>['/user-management/auth/login']],
				['label'=>'Logout', 'url'=>['/user-management/auth/logout']],
				['label'=>'Registration', 'url'=>['/user-management/auth/registration']],
				['label'=>'Change own password', 'url'=>['/user-management/auth/change-own-password']],
				['label'=>'Password recovery', 'url'=>['/user-management/auth/password-recovery']],
				['label'=>'E-mail confirmation', 'url'=>['/user-management/auth/confirm-email']],
			],
		],
	],
]);
?>


<?php
/************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
************************************************************************************************************/
5.2 Copiar de nuevo el contenido del archivo ===> views\layouts\main_original.php, a ===> views\layouts\main.php
5.3 Modificar la Nav en el archivo ===> views\layouts\main.php donde de muestran las etiquetas AQUI...?>
<?php
	.
	.
	.
	echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            ['label' => 'Home', 'url' => ['/site/index']],
            ['label' => 'About', 'url' => ['/site/about']],
            ['label' => 'Contact', 'url' => ['/site/contact']],
            Yii::$app->user->isGuest ? (
                ['label' => 'Login', 'url' => ['/user-management/auth/login']]   //<-------AQUÍ
            ) : (
                '<li>'
                . Html::beginForm(['/user-management/auth/logout'], 'post')      //<-------Y AQUÍ
                . Html::submitButton(
                    'Logout (' . Yii::$app->user->identity->username . ')',
                    ['class' => 'btn btn-link logout']
                )
                . Html::endForm()
                . '</li>'
            )
        ],
    ]);
	.
	.
	.
?>
<?php
/************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
*************************************************************************************************************
************************************************************************************************************/
6.1 Copiar al archivo ===>   views\site\index.php  
?>
<?php
use webvimark\modules\UserManagement\models\User;
use yii\helpers\Html;

/* @var $this yii\web\View */

$this->title = 'Proyecto';
?>
<h1><?= Html::encode($this->title) ?></h1>	

<?php if       (User::hasRole(['alumno'])) { ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/alumnos.png")       ,['/alumnos/index']       ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/cardex.png")        ,['/cardex/index']        ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/calificaciones.png"),['/calificaciones/index'],["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/carreras.png")      ,['/carreras/index']      ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/profesores.png")    ,['/profesores/index']    ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/coordinadores.png") ,['/coordinadores/index'] ,["class"=>"menu"]); ?>
<?php } else if(User::hasRole(['profesores'])) { ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/profesores.png")    ,['/profesores/index']    ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/calificaciones.png"),['/calificaciones/index'],["class"=>"menu"]); ?>
<?php } else if(User::hasRole(['coordinadores'])) { ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/coordinadores.png") ,['/coordinadores/index'] ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/alumnos.png")       ,['/alumnos/index']       ,["class"=>"menu"]); ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/carreras.png")      ,['/carreras/index']      ,["class"=>"menu"]); ?>
<?php } 
      if(User::hasRole(['alumnos','profesores','coordinadores'])) { ?>
      	<?= Html::a(Html::img($this->theme->baseUrl."/images/plantel.png")       ,['/plantel/index']       ,["class"=>"menu"]); ?>
      	<?= Html::a(Html::img($this->theme->baseUrl."/images/director.png")      ,['/director/index']      ,["class"=>"menu"]); ?>
<?php }
	  if(!Yii::$app->user->isGuest) { ?>
		<?= Html::a(Html::img($this->theme->baseUrl."/images/logout.png")        ,['/user-management/auth/logout'] ,["class"=>"menu"]); ?>
<?php } ?>